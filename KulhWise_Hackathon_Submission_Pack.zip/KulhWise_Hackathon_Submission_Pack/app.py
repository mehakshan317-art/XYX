import streamlit as st
import pandas as pd
import math
from datetime import datetime, date, time, timedelta
from kulhwise.core import allocate, fairness_index

st.set_page_config(page_title="KulhWise | Smart Canal Management", page_icon="💧", layout="wide")

# ----------------------------- Demo data / state -----------------------------
def seed_state():
    if "lang" not in st.session_state:
        st.session_state.lang = "English"
    if "farmers" not in st.session_state:
        # 30 fictional demo plots/farmers, for repeatable hackathon walkthroughs.
        villages = ["Upper Kuhl", "Middle Kuhl", "Lower Kuhl", "Tail-End Hamlet", "Riverside"]
        positions = ["Head", "Middle", "Tail"]
        priorities = ["Normal", "Normal", "High"]
        st.session_state.farmers = [
            {
                "id": f"F-{101+i}",
                "name": [
                    "Asha Devi", "Ravi Kumar", "Sunita Thakur", "Mohan Lal", "Kiran Sharma",
                    "Vijay Singh", "Pooja Verma", "Anil Kumar", "Rekha Devi", "Suresh Thakur",
                    "Neha Sharma", "Ramesh Lal", "Meena Devi", "Deepak Singh", "Kavita Rana",
                    "Arjun Kumar", "Seema Thakur", "Rajesh Verma", "Nisha Devi", "Manoj Sharma",
                    "Priya Singh", "Om Prakash", "Geeta Rana", "Harish Kumar", "Anita Devi",
                    "Dinesh Thakur", "Komal Sharma", "Yash Pal", "Rita Verma", "Tarun Singh"
                ][i],
                "village": villages[i % len(villages)],
                "area": round(0.6 + (i % 7) * 0.35, 2),
                "position": positions[min(2, (i * 3) // 30)],
                "demand": 40 + (i % 6) * 20,
                "priority": priorities[i % len(priorities)]
            }
            for i in range(30)
        ]
    if "canal_sections" not in st.session_state:
        st.session_state.canal_sections = [
            {"id": "C-1", "name": "Head Reach", "village": "Upper Kuhl", "level": 88, "seepage": 8, "flow": "Normal", "note": "Intake and upper distributary"},
            {"id": "C-2", "name": "Middle Reach", "village": "Middle Kuhl", "level": 66, "seepage": 18, "flow": "Watch", "note": "Moderate seepage indicators"},
            {"id": "C-3", "name": "Tail Reach", "village": "Lower Kuhl", "level": 34, "seepage": 38, "flow": "Critical", "note": "Low flow; inspect lining and outlets"},
            {"id": "C-4", "name": "Tail-End Outlet", "village": "Tail-End Hamlet", "level": 27, "seepage": 44, "flow": "Critical", "note": "Potential shortage at tail end"},
        ]
    if "complaints" not in st.session_state:
        st.session_state.complaints = [
            {"id": "KW-2401", "farmer": "Sunita Thakur", "village": "Lower Kuhl", "type": "Water shortage", "severity": "High", "details": "Water did not reach the outlet during the assigned turn.", "status": "Pending", "created": "Demo entry"},
            {"id": "KW-2402", "farmer": "Mohan Lal", "village": "Tail-End Hamlet", "type": "Possible seepage", "severity": "High", "details": "Wet patch beside the canal and reduced flow.", "status": "Verified", "created": "Demo entry"},
        ]
    if "audit" not in st.session_state:
        st.session_state.audit = [{"time": datetime.now().strftime("%Y-%m-%d %H:%M"), "actor": "System", "action": "Demo workspace initialized"}]
    if "schedule" not in st.session_state:
        st.session_state.schedule = []
    if "last_supply" not in st.session_state:
        st.session_state.last_supply = 300

seed_state()

T = {
    "English": {
        "Home":"Home", "Farmer Portal":"Farmer Portal", "Department Dashboard":"Department Dashboard",
        "Water Scheduler":"Water Scheduler", "Canal Map":"Canal Map", "Fairness Analytics":"Fairness Analytics", "Audit Log":"Audit Log",
        "nav":"Navigation", "language":"Language / भाषा", "subtitle":"Shared canal irrigation, made more transparent.",
        "intro":"KulhWise helps communities coordinate irrigation turns, report shortages, and identify canal sections that may need inspection.",
        "farmers":"Registered demo farmers", "reports":"Open reports", "critical":"Critical canal sections", "supply":"Last planned supply",
        "quick":"Quick actions", "map_hint":"Select a canal section to inspect its readings and update its condition.",
        "save":"Save changes", "submit":"Submit report", "calculate":"Calculate allocation", "save_schedule":"Save schedule",
        "success":"Changes saved in this session.", "reset":"Reset demo data", "reset_help":"Restore the sample data for your demo.",
        "tail":"Tail-end access", "allocation":"Allocation preview", "fairness":"Fairness index",
    },
    "हिन्दी": {
        "Home":"होम", "Farmer Portal":"किसान पोर्टल", "Department Dashboard":"विभाग डैशबोर्ड",
        "Water Scheduler":"जल समय-सारणी", "Canal Map":"कूहल मानचित्र", "Fairness Analytics":"न्यायसंगतता विश्लेषण", "Audit Log":"ऑडिट लॉग",
        "nav":"नेविगेशन", "language":"भाषा / Language", "subtitle":"साझा कूहल सिंचाई, अधिक पारदर्शी तरीके से।",
        "intro":"KulhWise सिंचाई की बारी तय करने, पानी की कमी की शिकायत दर्ज करने और निरीक्षण योग्य कूहल हिस्सों की पहचान करने में मदद करता है।",
        "farmers":"पंजीकृत डेमो किसान", "reports":"खुली शिकायतें", "critical":"गंभीर कूहल हिस्से", "supply":"पिछली नियोजित आपूर्ति",
        "quick":"त्वरित कार्य", "map_hint":"रीडिंग देखने और स्थिति बदलने के लिए कूहल का हिस्सा चुनें।",
        "save":"बदलाव सहेजें", "submit":"शिकायत भेजें", "calculate":"आवंटन निकालें", "save_schedule":"समय-सारणी सहेजें",
        "success":"बदलाव इस सत्र में सहेजे गए।", "reset":"डेमो डेटा रीसेट करें", "reset_help":"डेमो के लिए नमूना डेटा बहाल करें।",
        "tail":"अंतिम छोर तक पहुँच", "allocation":"आवंटन पूर्वावलोकन", "fairness":"न्यायसंगतता सूचकांक",
    }
}
def tr(key):
    return T[st.session_state.lang].get(key, key)

def log_action(actor, action):
    st.session_state.audit.insert(0, {"time": datetime.now().strftime("%Y-%m-%d %H:%M"), "actor": actor, "action": action})

def current_allocation(supply=None):
    supply = st.session_state.last_supply if supply is None else supply
    return allocate(supply, st.session_state.farmers)

# ----------------------------- Sidebar navigation -----------------------------
with st.sidebar:
    st.markdown("## 💧 KulhWise")
    st.caption("Smart shared-canal irrigation")
    st.selectbox(tr("language"), ["English", "हिन्दी"], key="lang")
    pages = ["Home", "Farmer Portal", "Department Dashboard", "Water Scheduler", "Canal Map", "Fairness Analytics", "Audit Log"]
    page = st.radio(tr("nav"), pages, format_func=lambda x: tr(x))
    st.divider()
    st.caption("Hackathon demo • sample data")
    if st.button(tr("reset"), use_container_width=True):
        for key in ["farmers", "canal_sections", "complaints", "audit", "schedule", "last_supply"]:
            st.session_state.pop(key, None)
        seed_state()
        log_action("System", "Demo data reset")
        st.rerun()

st.title("💧 KulhWise")
st.caption(tr("subtitle"))
st.write(tr("intro"))

# ----------------------------- Home -----------------------------
if page == "Home":
    open_reports = sum(c["status"] != "Resolved" for c in st.session_state.complaints)
    critical = sum(c["flow"] == "Critical" for c in st.session_state.canal_sections)
    a, b, c, d = st.columns(4)
    a.metric(tr("farmers"), len(st.session_state.farmers))
    b.metric(tr("reports"), open_reports, help="Pending and verified reports")
    c.metric(tr("critical"), critical)
    d.metric(tr("supply"), f'{st.session_state.last_supply} units')
    st.subheader(tr("quick"))
    q1, q2, q3 = st.columns(3)
    with q1:
        st.info("🗺️ **Canal Map**\n\nInspect canal conditions and seepage risk.")
    with q2:
        st.info("🧮 **Water Scheduler**\n\nAdjust supply and preview allocation before saving.")
    with q3:
        st.info("🧑‍🌾 **Farmer reports**\n\nSubmit and track water shortage or seepage issues.")
    st.subheader("Current canal status")
    canal_df = pd.DataFrame(st.session_state.canal_sections)
    st.dataframe(canal_df[["id", "name", "village", "level", "seepage", "flow"]].rename(columns={"level":"Water level %", "seepage":"Seepage risk %", "flow":"Status"}), use_container_width=True, hide_index=True)
    st.caption("Demo values are illustrative and are not live sensor readings.")

# ----------------------------- Farmer portal -----------------------------
elif page == "Farmer Portal":
    st.subheader("🧑‍🌾 Report a water issue")
    farmer_names = [f["name"] for f in st.session_state.farmers]
    with st.form("report_form", clear_on_submit=True):
        who = st.selectbox("Farmer", farmer_names)
        issue = st.selectbox("Issue type", ["Water shortage", "Possible seepage", "Blocked outlet", "Schedule conflict", "Other"])
        severity = st.select_slider("Severity", options=["Low", "Medium", "High", "Critical"], value="Medium")
        details = st.text_area("What happened?", placeholder="Describe the canal section, time, and what you observed.")
        submitted = st.form_submit_button(tr("submit"), use_container_width=True)
    if submitted:
        if not details.strip():
            st.error("Please add a short description before submitting.")
        else:
            farmer = next(f for f in st.session_state.farmers if f["name"] == who)
            report_id = f"KW-{2400 + len(st.session_state.complaints) + 1}"
            st.session_state.complaints.insert(0, {"id": report_id, "farmer": who, "village": farmer["village"], "type": issue, "severity": severity, "details": details.strip(), "status": "Pending", "created": datetime.now().strftime("%Y-%m-%d %H:%M")})
            log_action(who, f"Submitted {issue} report {report_id}")
            st.success(f"Report submitted. Your report ID is **{report_id}**.")
    st.subheader("Track a report")
    report_ids = [c["id"] for c in st.session_state.complaints]
    if report_ids:
        selected_id = st.selectbox("Choose report ID", report_ids)
        selected = next(c for c in st.session_state.complaints if c["id"] == selected_id)
        left, right = st.columns([1, 2])
        with left:
            st.metric("Current status", selected["status"])
            st.caption(f"Farmer: {selected['farmer']}")
        with right:
            st.write(f"**Issue:** {selected['type']} · **Severity:** {selected['severity']}")
            st.write(selected["details"])
    st.subheader("All submitted reports")
    if st.session_state.complaints:
        st.dataframe(pd.DataFrame(st.session_state.complaints), use_container_width=True, hide_index=True)

# ----------------------------- Department dashboard -----------------------------
elif page == "Department Dashboard":
    st.subheader("🏢 Department review desk")
    reports = st.session_state.complaints
    pending = sum(c["status"] == "Pending" for c in reports)
    verified = sum(c["status"] == "Verified" for c in reports)
    resolved = sum(c["status"] == "Resolved" for c in reports)
    m1, m2, m3 = st.columns(3)
    m1.metric("Pending", pending)
    m2.metric("Verified", verified)
    m3.metric("Resolved", resolved)
    st.subheader("Review a report")
    if reports:
        chosen = st.selectbox("Report", [c["id"] for c in reports], key="dept_report")
        report = next(c for c in reports if c["id"] == chosen)
        st.write(f"**{report['type']}** · {report['severity']} severity · {report['village']}")
        st.write(report["details"])
        new_status = st.selectbox("Update status", ["Pending", "Verified", "Resolved"], index=["Pending", "Verified", "Resolved"].index(report["status"]), key=f"status_{chosen}")
        note = st.text_input("Department note (optional)", key=f"note_{chosen}", placeholder="e.g., Site inspection assigned")
        if st.button("Apply status update", type="primary"):
            report["status"] = new_status
            if note.strip():
                report["department_note"] = note.strip()
            log_action("Department", f"Updated report {chosen} to {new_status}" + (f" — {note.strip()}" if note.strip() else ""))
            st.success(f"{chosen} updated to {new_status}.")
            st.rerun()
    st.subheader("Canal condition controls")
    section_names = [s["name"] for s in st.session_state.canal_sections]
    selected_section = st.selectbox("Canal section", section_names, key="dept_section")
    section = next(s for s in st.session_state.canal_sections if s["name"] == selected_section)
    with st.form("canal_update"):
        level = st.slider("Water level (%)", 0, 100, int(section["level"]))
        seepage = st.slider("Seepage risk (%)", 0, 100, int(section["seepage"]))
        flow = st.selectbox("Flow status", ["Normal", "Watch", "Critical"], index=["Normal", "Watch", "Critical"].index(section["flow"]))
        update = st.form_submit_button("Save canal condition")
    if update:
        section.update({"level": level, "seepage": seepage, "flow": flow})
        log_action("Department", f"Updated canal section {section['id']} readings")
        st.success("Canal readings updated.")
        st.rerun()
    st.subheader("All reports")
    st.dataframe(pd.DataFrame(reports), use_container_width=True, hide_index=True)

# ----------------------------- Scheduler -----------------------------
elif page == "Water Scheduler":
    st.subheader("🧮 Plan a fair water distribution")
    st.write("Adjust available supply and farmer details, then calculate a preview. Saving records the schedule in this session.")
    supply = st.slider("Available water supply (units)", min_value=50, max_value=600, value=int(st.session_state.last_supply), step=10)
    st.caption("Allocation is proportional to land area, gives high-priority farmers a modest weighting, and respects each farmer's stated demand.")
    with st.expander("Edit demo farmer demand and land area", expanded=False):
        for f in st.session_state.farmers:
            st.markdown(f"**{f['name']}** · {f['id']}")
            c1, c2, c3 = st.columns(3)
            f["area"] = c1.number_input(f"Land area (ha) · {f['id']}", min_value=0.1, max_value=100.0, value=float(f["area"]), step=0.1, key=f"area_{f['id']}")
            f["demand"] = c2.number_input(f"Demand (units) · {f['id']}", min_value=10, max_value=1000, value=int(f["demand"]), step=10, key=f"demand_{f['id']}")
            f["priority"] = c3.selectbox(f"Priority · {f['id']}", ["Normal", "High"], index=["Normal", "High"].index(f["priority"]), key=f"priority_{f['id']}")
    alloc = allocate(supply, st.session_state.farmers)
    demand_total = sum(f["demand"] for f in st.session_state.farmers)
    col1, col2, col3 = st.columns(3)
    col1.metric("Available supply", f"{supply} units")
    col2.metric("Total demand", f"{demand_total} units")
    col3.metric("Unmet demand", f"{max(0, demand_total - sum(alloc)):.1f} units")
    preview = []
    for f, amount in zip(st.session_state.farmers, alloc):
        preview.append({"Farmer": f["name"], "Village": f["village"], "Position": f["position"], "Land (ha)": f["area"], "Demand": f["demand"], "Allocated": amount, "Shortfall": round(max(0, f["demand"] - amount), 1), "Priority": f["priority"]})
    df = pd.DataFrame(preview)
    st.subheader(tr("allocation"))
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.bar_chart(df.set_index("Farmer")[["Demand", "Allocated"]])
    tail_names = [f["name"] for f in st.session_state.farmers if f["position"] == "Tail"]
    tail_alloc = [alloc[i] for i, f in enumerate(st.session_state.farmers) if f["position"] == "Tail"]
    tail_demand = sum(f["demand"] for f in st.session_state.farmers if f["position"] == "Tail")
    st.metric(tr("tail"), f"{sum(tail_alloc):.1f} / {tail_demand} units")
    c1, c2 = st.columns(2)
    with c1:
        if st.button(tr("calculate"), use_container_width=True):
            st.session_state.preview_alloc = preview
            st.success("Allocation recalculated from current inputs.")
    with c2:
        if st.button(tr("save_schedule"), type="primary", use_container_width=True):
            st.session_state.last_supply = supply
            st.session_state.schedule = [{"saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"), **row} for row in preview]
            log_action("Department", f"Saved water schedule for {len(preview)} farmers; supply {supply} units")
            st.success(tr("success"))
    if st.session_state.schedule:
        st.subheader("Latest saved schedule")
        st.dataframe(pd.DataFrame(st.session_state.schedule), use_container_width=True, hide_index=True)

# ----------------------------- Interactive canal map -----------------------------
elif page == "Canal Map":
    st.subheader("🗺️ Canal condition explorer")
    st.write(tr("map_hint"))
    sections = st.session_state.canal_sections
    selected_id = st.selectbox("Choose a canal section", [s["id"] for s in sections], format_func=lambda sid: next(f"{s['id']} — {s['name']}" for s in sections if s["id"] == sid))
    selected = next(s for s in sections if s["id"] == selected_id)
    # A simple visual schematic: each segment is clickable through the selector above.
    cols = st.columns(len(sections))
    for i, (col, section) in enumerate(zip(cols, sections)):
        color = "#16803c" if section["flow"] == "Normal" else ("#c58b12" if section["flow"] == "Watch" else "#c43131")
        with col:
            st.markdown(f"""
            <div style="border:2px solid {color};border-radius:12px;padding:12px 8px;text-align:center;background:rgba(120,120,120,0.06);min-height:120px">
              <div style="font-size:12px;color:inherit">{section['id']}</div>
              <div style="font-weight:700;margin:5px 0">{section['name']}</div>
              <div style="font-size:13px">Water {section['level']}%</div>
              <div style="font-size:13px">Seepage {section['seepage']}%</div>
              <div style="font-weight:700;color:{color};margin-top:6px">{section['flow']}</div>
            </div>""", unsafe_allow_html=True)
            if st.button("Inspect" if section["id"] != selected_id else "Selected ✓", key=f"inspect_{section['id']}", use_container_width=True):
                st.session_state.selected_canal = section["id"]
                st.rerun()
    if "selected_canal" in st.session_state:
        selected_id = st.session_state.selected_canal
        selected = next((s for s in sections if s["id"] == selected_id), selected)
    st.divider()
    left, right = st.columns([1, 1])
    with left:
        st.subheader(f"{selected['id']} · {selected['name']}")
        st.write(f"**Village:** {selected['village']}")
        st.write(selected["note"])
        st.metric("Water level", f"{selected['level']}%")
        st.metric("Seepage risk indicator", f"{selected['seepage']}%")
        if selected["seepage"] >= 35 or selected["level"] < 35:
            st.error("Inspection recommended: high seepage indicator or low water level.")
        elif selected["seepage"] >= 15 or selected["level"] < 60:
            st.warning("Monitor this section during the next irrigation turn.")
        else:
            st.success("No demo threshold alert for this section.")
    with right:
        st.subheader("Condition trend (illustrative)")
        st.line_chart(pd.DataFrame({"Water level (%)":[max(0, selected["level"]-12), max(0, selected["level"]-7), selected["level"]], "Seepage risk (%)":[max(0, selected["seepage"]-5), max(0, selected["seepage"]-2), selected["seepage"]]}, index=["Earlier", "Recent", "Current"]))
        st.caption("Trend points are illustrative demo values, not measured history.")
    st.info("This is a clickable schematic, not a surveyed geographic map. Connect field sensors/GIS data for real-world readings.")

# ----------------------------- Analytics -----------------------------
elif page == "Fairness Analytics":
    st.subheader("📊 Water allocation and fairness")
    if st.session_state.schedule:
        data = st.session_state.schedule
        df = pd.DataFrame(data)
        alloc_col = "Allocated"
        demand_col = "Demand"
    else:
        amounts = current_allocation()
        df = pd.DataFrame([{"Farmer": f["name"], "Demand": f["demand"], "Allocated": amounts[i], "Position": f["position"], "Village": f["village"]} for i, f in enumerate(st.session_state.farmers)])
    idx = fairness_index(df["Allocated"].tolist())
    unmet = max(0, df["Demand"].sum() - df["Allocated"].sum())
    fulfilled = 100 * df["Allocated"].sum() / max(1, df["Demand"].sum())
    m1, m2, m3 = st.columns(3)
    m1.metric(tr("fairness"), f"{idx:.3f}", help="Jain's fairness index: 1.0 means equal allocation values. Interpret alongside each farmer's demand and land area.")
    m2.metric("Demand fulfilled", f"{fulfilled:.1f}%")
    m3.metric("Total shortfall", f"{unmet:.1f} units")
    st.subheader("Demand vs allocation")
    st.bar_chart(df.set_index("Farmer")[["Demand", "Allocated"]])
    st.subheader("Allocation by canal position")
    if "Position" in df:
        pos = df.groupby("Position")[["Demand", "Allocated"]].sum()
        st.bar_chart(pos)
    st.subheader("Canal risk overview")
    canal_df = pd.DataFrame(st.session_state.canal_sections)
    st.bar_chart(canal_df.set_index("name")[["level", "seepage"]].rename(columns={"level":"Water level %", "seepage":"Seepage risk %"}))
    st.caption("All values are sample data. Jain's index measures equality of allocation amounts, not whether allocation is fair against demand, land, or local rules.")

# ----------------------------- Audit log -----------------------------
elif page == "Audit Log":
    st.subheader("🧾 Action history")
    st.write("This session records key demo actions such as report submissions, status changes, canal updates, and saved schedules.")
    if st.session_state.audit:
        st.dataframe(pd.DataFrame(st.session_state.audit), use_container_width=True, hide_index=True)
        st.download_button("Download audit log CSV", pd.DataFrame(st.session_state.audit).to_csv(index=False).encode("utf-8"), file_name="kulhwise_audit_log.csv", mime="text/csv")
    else:
        st.info("No actions recorded yet.")

st.divider()
st.caption("KulhWise hackathon prototype · Demo data only · Session changes reset when the app process restarts.")
