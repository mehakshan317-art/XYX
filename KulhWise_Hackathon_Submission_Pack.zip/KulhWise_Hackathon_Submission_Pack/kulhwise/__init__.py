"""KulhWise application package."""
