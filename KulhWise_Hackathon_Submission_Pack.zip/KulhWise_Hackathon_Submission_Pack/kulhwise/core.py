"""Core allocation and fairness calculations for KulhWise."""
def fairness_index(values):
    vals = [max(0, float(v)) for v in values]
    if not vals or sum(v * v for v in vals) == 0:
        return 0.0
    return (sum(vals) ** 2) / (len(vals) * sum(v * v for v in vals))


def allocate(supply, farmers):
    """Illustrative allocation: land-area weighting, modest high-priority weight, demand cap."""
    weights = []
    for farmer in farmers:
        factor = 1.15 if farmer["priority"] == "High" else 1.0
        weights.append(max(0.1, float(farmer["area"])) * factor)
    total = sum(weights) or 1
    raw = [float(supply) * w / total for w in weights]
    allocations = [min(raw[i], float(farmers[i]["demand"])) for i in range(len(farmers))]
    leftover = max(0.0, float(supply) - sum(allocations))
    for _ in range(len(farmers) + 1):
        unmet = [i for i, farmer in enumerate(farmers) if allocations[i] < float(farmer["demand"])]
        if leftover <= 0.01 or not unmet:
            break
        denom = sum(weights[i] for i in unmet) or 1
        moved = 0.0
        for i in unmet:
            add = min(float(farmers[i]["demand"]) - allocations[i], leftover * weights[i] / denom)
            allocations[i] += add
            moved += add
        leftover -= moved
        if moved <= 0.01:
            break
    return [round(value, 1) for value in allocations]
