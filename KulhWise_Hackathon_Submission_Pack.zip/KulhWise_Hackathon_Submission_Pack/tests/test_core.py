import unittest
from kulhwise.core import allocate, fairness_index


class KulhWiseCoreTests(unittest.TestCase):
    def setUp(self):
        self.farmers = [
            {"area": 2.0, "demand": 100, "priority": "Normal"},
            {"area": 1.0, "demand": 100, "priority": "High"},
        ]

    def test_allocation_nonnegative(self):
        result = allocate(100, self.farmers)
        self.assertTrue(all(value >= 0 for value in result))

    def test_allocation_does_not_exceed_demand(self):
        result = allocate(1000, self.farmers)
        self.assertLessEqual(result[0], self.farmers[0]["demand"])
        self.assertLessEqual(result[1], self.farmers[1]["demand"])

    def test_supply_distributed_when_demand_is_enough(self):
        result = allocate(100, self.farmers)
        self.assertAlmostEqual(sum(result), 100, delta=0.2)

    def test_fairness_index_bounds(self):
        value = fairness_index([10, 20, 30])
        self.assertGreaterEqual(value, 0)
        self.assertLessEqual(value, 1.000001)

    def test_equal_values_have_index_one(self):
        self.assertAlmostEqual(fairness_index([5, 5, 5]), 1.0)

    def test_empty_values(self):
        self.assertEqual(fairness_index([]), 0.0)


if __name__ == "__main__":
    unittest.main()
