# KulhWise — Hackathon Submission Pack

**One-line description:** KulhWise is a digital shared-canal irrigation coordination prototype that helps farmers report water shortages and possible seepage, helps departments review issues, and provides transparent, illustrative water-allocation planning.

## Submission deliverables checklist

- [x] Project name and description in this README
- [x] Organized source code and requirements
- [x] Demo dataset with 30 fictional farmers/plots
- [x] Core allocation/fairness logic separated into `kulhwise/core.py`
- [x] Basic automated tests in `tests/`
- [x] Firebase setup/security planning guide in `docs/FIREBASE_SETUP_AND_SECURITY.md`
- [ ] Public GitHub repository — create/publish from your GitHub account
- [ ] Live demo URL — deploy the repository using Streamlit Community Cloud or another host
- [ ] Demo video URL — record and upload using your account
- [ ] Pitch deck — prepare/upload the slide deck for your hackathon portal

The last four are account-based external deliverables; this ZIP cannot publish them or create account URLs for you.

## Features in the prototype

- Home dashboard and session metrics
- Farmer portal: submit water-shortage/seepage reports and track report IDs/status
- Department dashboard: review reports and update status/notes
- Canal-condition controls and interactive schematic canal map
- Water scheduler: change supply, land area, demand and priority; calculate and save an illustrative allocation
- Fairness analytics: demand vs allocation, canal risk charts and Jain's fairness index
- Audit log with CSV download
- English/Hindi navigation and selected interface labels
- 30 fictional demo farmers/plots for a fuller walkthrough

## Run locally on Windows

1. Extract this folder to your chosen project directory. Keep your original `kulhwise` folder untouched.
2. Open Command Prompt in this folder, then run:

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m streamlit run app.py
```

3. Open the local URL shown in Command Prompt, usually `http://localhost:8501`.

## Run tests

```bat
python -m unittest discover -s tests -v
```

## Demo flow for judges

1. Home: introduce the shared-canal coordination problem.
2. Farmer Portal: submit a shortage or possible seepage report.
3. Department Dashboard: verify/resolve it and update a canal section.
4. Canal Map: inspect water-level and seepage indicators.
5. Water Scheduler: change supply and save a schedule.
6. Fairness Analytics: explain allocation and tail-end access.
7. Audit Log: show traceable demo actions.

## Accuracy and limitations

- Data are fictional demo data; they are not live measurements.
- The map is a schematic, not a surveyed GIS map.
- Session-state data are temporary and may reset when a session/process restarts.
- No real sensors, SMS alerts, user authentication, or persistent database are connected in this version.
- The allocation method is an illustrative policy (area weighting, modest high-priority weighting, and demand caps). It must not be presented as a validated irrigation authority rule.
- Jain's fairness index measures equality of allocation amounts; it does not by itself prove fairness relative to need, land, crop, location, or local rules.

## Suggested 6–8 slide pitch deck

1. Title: KulhWise — Transparent Shared Canal Irrigation
2. Problem: scheduling conflicts, unclear records, potential tail-end shortages
3. Solution: one workflow for farmer reports, department review, canal-condition view and scheduling
4. Product demo: report → verify → inspect map → schedule
5. Allocation logic: show inputs, rules and an example; label values as simulated
6. Impact and measurement plan: response time, report closure, tail-end delivery, recorded seepage inspections
7. Technology and responsible deployment: Streamlit, Python, pandas; future GIS/sensors/database integration
8. Roadmap and ask: pilot with local irrigation stakeholders, validate policy and data

## Public repository and live demo

After testing, create a **public** GitHub repository, upload these files, then deploy it. Add your real repository and deployed demo URLs to the hackathon form only after opening them in a private/incognito browser to verify public access.
