# Firebase setup and security guidance (future integration)

## Current status
The submitted prototype does **not** connect to Firebase. It uses Streamlit session state because the current demo requirement is session storage. This document describes a safe path if persistent, multi-user storage is added later; do not claim Firebase is integrated until code and deployment are tested.

## Suggested data model
- `farmers`: farmer ID, display name, village, plot area, consent/created timestamp
- `reports`: report ID, farmer reference, issue type, severity, details, status, timestamps, department note
- `canal_sections`: section ID, water level, seepage indicator, flow status, last-updated timestamp
- `schedules`: schedule ID, period, supply, allocation rows, created-by, created-at
- `audit_logs`: actor ID/role, action, entity ID, timestamp

## Setup outline
1. Create a Firebase project in the Firebase console.
2. Enable Firebase Authentication before allowing real users.
3. Create a Firestore database in a suitable region after checking applicable data requirements.
4. Define role-based access for farmer, department, and administrator.
5. Use Firestore Security Rules to enforce least privilege: farmers may create/read only their own reports; department users may review reports and update allowed fields; only authorized administrators may change role assignments.
6. Test rules in the Firebase Emulator Suite before production.
7. Configure secrets through the deployment platform's secrets/environment settings. Never commit service-account JSON, API secrets, passwords, or `.env` files to a public repository.
8. Add audit events server-side so users cannot forge or delete their own audit history.
9. Add backups, retention rules, error monitoring, and a process for removing personal data.

## Security checklist
- [ ] Authentication and role checks enabled
- [ ] Firestore rules deny access by default
- [ ] No credentials in source control
- [ ] Inputs validated and text fields bounded
- [ ] Personal data minimized; demo names are fictional
- [ ] Rules tested with allowed and denied cases
- [ ] Production data separated from demo data
- [ ] Security review completed before use with real farmers

This guide is not a claim of certification or production readiness.
