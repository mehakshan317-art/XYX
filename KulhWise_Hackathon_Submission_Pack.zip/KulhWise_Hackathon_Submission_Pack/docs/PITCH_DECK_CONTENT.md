# KulhWise Pitch Deck Content (8 slides)

## Slide 1 — KulhWise
**Transparent shared-canal irrigation coordination**
A digital workflow for farmer reports, department follow-up, canal-condition visibility, and illustrative water scheduling.
Presenter: [Your team name]

## Slide 2 — The problem
Shared canal systems rely on coordinated turns and clear records. Manual processes can make conflicts and shortages hard to report, verify, and track. Tail-end farmers may be especially vulnerable when flow is limited.
**Important:** Present these as problem context, not quantified findings, unless your team has local evidence.

## Slide 3 — Our solution
KulhWise connects:
- Farmer shortage/seepage reporting
- Department review and status updates
- A canal-condition schematic with risk indicators
- Water allocation planning and fairness analytics
- An action log for traceability

## Slide 4 — Product workflow
**Report → Review → Inspect → Schedule → Analyze**
Use a live demo or screenshots of each step. Demonstrate one report moving from Pending to Verified/Resolved.

## Slide 5 — How scheduling works
Inputs: available supply, plot area, demand, and priority.
Prototype rule: area-weighted distribution, modest priority weighting, and a cap at stated demand.
Show a sample allocation table and explain unmet demand.
**Label all displayed figures as simulated demo data.** The formula is illustrative and must be validated with local irrigation authorities.

## Slide 6 — Potential impact and evaluation
Potential measures for a pilot:
- Time from report submission to department action
- Percentage of reports resolved
- Planned versus delivered water by canal position
- Tail-end shortage frequency
- Number of seepage inspections and verified repairs
Do not claim measured impact until a pilot produces evidence.

## Slide 7 — Technology and responsible use
Python, Streamlit, pandas; modular allocation logic and basic unit tests.
Current prototype uses temporary session data and a schematic map. Future work: authenticated roles, persistent database, GIS, field-verified measurements, and sensor integration.
Privacy/security guidance is included in the repository.

## Slide 8 — Roadmap and ask
1. Validate allocation rules with local irrigation stakeholders.
2. Pilot with a small canal community.
3. Collect consent-based field data and evaluate outcomes.
4. Add persistent storage, role-based access, and GIS/sensor integrations.
**Ask:** mentors/partners for a controlled pilot and domain validation.
